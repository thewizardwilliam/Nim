var one1 = document.getElementById("11");
var two1 = document.getElementById("21");
var two2 = document.getElementById("22");
var two3 = document.getElementById("23");
var three1 = document.getElementById("31");
var three2 = document.getElementById("32");
var three3 = document.getElementById("33");
var three4 = document.getElementById("34");
var three5 = document.getElementById("35");
var four1 = document.getElementById("41");
var four2 = document.getElementById("42");
var four3 = document.getElementById("43");
var four4 = document.getElementById("44");
var four5 = document.getElementById("45");
var four6 = document.getElementById("46");
var four7 = document.getElementById("47");
function oneOne() {
    one1.hidden = "true";
}
function twoOne() {
    two1.hidden = "true";
}
function twoTwo() {
    two2.hidden = "true";
}
function twoThree() {
    two3.hidden = "true";
}
function threeOne() {
    three1.hidden = "true";
}
function threeTwo() {
    three2.hidden = "true";
}
function threeThree() {
    three3.hidden = "true";
}
function threeFour() {
    three4.hidden = "true";
}
function threeFive() {
    three5.hidden = "true";
}
function fourOne() {
    four1.hidden = "true";
}
function fourTwo() {
    four2.hidden = "true";
}
function fourThree() {
    four3.hidden = "true";
}
function fourFour() {
    four4.hidden = "true";
}
function fourFive() {
    four5.hidden = "true";
}
function fourSix() {
    four6.hidden = "true";
}
function fourSeven() {
    four7.hidden = "true";
}